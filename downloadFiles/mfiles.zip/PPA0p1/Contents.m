% PPA toolbox
% Version 0.1		6-Jun-2005
% Copyright (c) 2005 Nathaniel J. King and Neil D. Lawrence
% 
% DEMPPA1 A simple demonstration of the probabilistic point assimilation.
% DEMPPA2 A simple overlapping data set.
% DEMPPA3 A simple demonstration on the Banana data.
% DEMPPA4 A simple demonstration. 
% PPA Set up a probabilistic point assimilation model. 
% PPACALCULATELOGLIKE Compute the log likelihood of the data.
% PPACALCULATELOGLIKE2 Compute the log likelihood of the data.
% PPACONTOUR Special contour plot showing decision boundary.
% PPACOVARIANCEGRADIENT The gradient of the likelihood approximation wrt the covariance.
% PPADISPLAY Display parameters of PPA model.
% PPAESTEP Perform the expectation step in the EM optimisation.
% PPAEXPECTF Compute the expectation of f.
% PPAEXPECTFBAR Expectation under q(fBar).
% PPAEXPECTFBARFBAR Second moment under q(fBar).
% PPAEXPECTFF Second moment of f under q(f).
% PPAGUNNARDATA Script for running experiments on Gunnar data.
% PPAGUNNARRESULTSTEST Helper script for collating results on Gunnar's benchmarks.
% PPAGUNNARTEST Script for running tests on Gunnar data.
% PPAINIT Initialise the probabilistic point assimilation model.
% PPAKERNELGRADIENT Gradient of likelihood approximation wrt kernel parameters.
% PPAKERNELLOGLIKEGRAD Gradient of the kernel likelihood wrt kernel parameters.
% PPAKERNELLOGLIKELIHOOD Return the approximate log-likelihood for the PPA.
% PPAKERNELOBJECTIVE Likelihood approximation.
% PPAMSTEP Perform the M-step for probabilistic point assimilation.
% PPAMESHVALS Give the output of the PPA for contour plot display.
% PPAOPTIMISEKERNEL Optimise the kernel parameters.
% PPAOPTIMISEPPA Optimise the probabilistic point assimilation model.
% PPAOPTIONS Default options for the probabilistic point assimilation.
% PPAOUT Evaluate the output of an ppa model.
% PPAPOSTERIORMEANVAR Mean and variances of the posterior at points given by X.
% PPATWODPLOT Make a 2-D plot of the PPA.
% PPAUPDATEB Update the individual values of B.
% PPAUPDATEBSCALAR Update the values of B keeping each data dimension constant.
% PPAUPDATEKERNEL Update the kernel parameters.
% PPAVARLIKECOVARIANCEGRADIENT The gradient of the variational likelihood approximation wrt the covariance.
% PPAVARLIKEKERNELGRADIENT Gradient of variational likelihood approximation wrt kernel parameters.
% PPVARLIKEAPPROXLOGLIKEKERNGRAD Gradient of the kernel variational likelihood wrt kernel parameters.
% PPAVARLIKEKERNELLOGLIKELIHOOD Return the approximate variational log-likelihood for the PPA.
% PPAVARLIKEKERNELOBJECTIVE Variational Likelihood Kernel approximation.
% PPAOPTIMISEKERNEL Optimise the kernel parameters using the variational log-likelihood.
