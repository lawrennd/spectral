% DEMPPA1 A simple demonstration of the probabilistic point assimilation.
%
%
% Copyright (c) 2005 Nathaniel J. King and Neil D. Lawrence
% File version 1.2, Fri Mar  4 20:52:04 2005
% PPA toolbox version 0.1



% Load the data
X=load('../data/rand_data.asc');
y=load('../data/rand_labels.asc');

% Define the noise model to be used
noiseModel='probit';

% Define the kernel to be used
kernelType={'rbf','bias', 'white'};

options = ppaOptions;
options.display = 2; % display graphically as we go.

model=ppa(X, y, noiseModel, kernelType);
model=ppaOptimisePPA(model, options);



