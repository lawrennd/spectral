function h = ppaContour(X, Y, Z, lineWidth)

% PPACONTOUR Special contour plot showing decision boundary.
%
% h = ppaContour(X, Y, Z, lineWidth)

% Copyright (c) 2005 Nathaniel J. King and Neil D. Lawrence
% File version 1.2, Fri Mar  4 21:02:05 2005
% PPA toolbox version 0.1



% It's probably learnt something.
[void, clines] =contour(X, Y, Z, [0.25 .75], 'b--');
h = clines;
set(clines, 'linewidth', lineWidth)
[void, clines] =contour(X, Y, Z, [0.5 0.5], 'r-');
set(clines, 'linewidth', lineWidth);
h = [h; clines];