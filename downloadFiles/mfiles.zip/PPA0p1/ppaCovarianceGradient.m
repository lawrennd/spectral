function g = ppaCovarianceGradient(invK, m)

% PPACOVARIANCEGRADIENT The gradient of the likelihood approximation wrt the covariance.
%
% g = ppaCovarianceGradient(invK, m)

% Copyright (c) 2005 Nathaniel J. King and Neil D. Lawrence
% File version 1.1, Sun Mar  6 18:43:38 2005
% PPA toolbox version 0.1



invKm = invK*m;

g = -invK + invKm*invKm';
g= g*.5;
