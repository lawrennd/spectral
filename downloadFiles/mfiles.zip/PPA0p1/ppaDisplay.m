function ppaDisplay(model)

% PPADISPLAY Display parameters of PPA model.
%
% ppaDisplay(model)

% Copyright (c) 2005 Nathaniel J. King and Neil D. Lawrence
% File version 1.1, Mon Mar  7 08:10:44 2005
% PPA toolbox version 0.1



noiseDisplay(model.noise);
kernDisplay(model.kern);