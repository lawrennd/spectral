function model = ppaExpectfBar(model)

% PPAEXPECTFBAR Expectation under q(fBar).
%
% model = ppaExpectfBar(model)

% Copyright (c) 2005 Nathaniel J. King and Neil D. Lawrence
% File version 1.2, Fri Jun  3 20:47:53 2005
% PPA toolbox version 0.1



for i = 1:size(model.y, 2)
    model.expectations.fBar(:, i) = pdinv(diag(model.B(:, i)) + ...
                                              pdinv(model.kern.Kstore))...
                                         *diag(model.B(:, i))...
                                         *model.expectations.f(:, i);
end