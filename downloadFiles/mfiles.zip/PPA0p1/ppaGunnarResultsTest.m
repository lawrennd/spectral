function ppaGunnarResultsTest(dataSet);

% PPAGUNNARRESULTSTEST Helper script for collating results on Gunnar's benchmarks.
%
% ppaGunnarResultsTest(dataSet);

% Copyright (c) 2005 Nathaniel J. King and Neil D. Lawrence
% File version 1.1, Tue Mar  8 16:44:15 2005
% PPA toolbox version 0.1


beta = 0;
load(['ppa' dataSet 'Rbf']);
b = beta;
for dataNum = 1:10
  er(dataNum) = ppaGunnarTest(dataSet, dataNum, {'rbf', 'bias', 'white'}, ...
                                 kernParam, noiseParam, b);
end
save(dataSet, 'er');