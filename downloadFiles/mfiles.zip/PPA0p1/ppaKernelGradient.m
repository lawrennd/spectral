function g = ppaKernelGradient(params, model)

% PPAKERNELGRADIENT Gradient of likelihood approximation wrt kernel parameters.
%
% g = ppaKernelGradient(params, model)

% Copyright (c) 2005 Nathaniel J. King and Neil D. Lawrence
% File version 1.1, Sun Mar  6 18:38:41 2005
% PPA toolbox version 0.1




model.kern = kernExpandParam(model.kern, params);
g = ppaKernelLogLikeGrad(model);
g = g + kernPriorGradient(model.kern);
g = -g;

