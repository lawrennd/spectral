function g = ppaKernelLogLikeGrad(model)

% PPAKERNELLOGLIKEGRAD Gradient of the kernel likelihood wrt kernel parameters.
%
% g = ppaKernelLogLikeGrad(model)

% Copyright (c) 2005 Nathaniel J. King and Neil D. Lawrence
% File version 1.2, Fri Jun  3 20:47:53 2005
% PPA toolbox version 0.1



x = model.X;
m = model.expectations.f;
K = kernCompute(model.kern, x);
g = zeros(1, model.kern.nParams);

if model.noise.spherical
  % there is only one value for all beta
  invK = pdinv(K+diag(1./model.B(:, 1)));
end

for j = 1:size(m, 2)
  if ~model.noise.spherical
    invK = pdinv(K+diag(1./model.B(:, j)));
  end
  covGrad = feval([model.type 'CovarianceGradient'], invK, m(:, j));
  g = g + kernGradient(model.kern, x, covGrad);
end  
