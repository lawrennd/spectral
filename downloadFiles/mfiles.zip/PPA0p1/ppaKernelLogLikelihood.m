function L = ppaKernelLogLikelihood(model);

% PPAKERNELLOGLIKELIHOOD Return the approximate log-likelihood for the PPA.
%
% L = ppaKernelLogLikelihood(model);

% Copyright (c) 2005 Nathaniel J. King and Neil D. Lawrence
% File version 1.2, Fri Jun  3 20:54:07 2005
% PPA toolbox version 0.1



x = model.X;
m = model.expectations.f;
K = kernCompute(model.kern, x);
L = 0;

if model.noise.spherical
  % there is only one value for all beta
  [invK, UC] = pdinv(K+diag(1./model.B(:, 1)));
  logDetTerm = logdet(K, UC);
end
  
for i = 1:size(m, 2)
  if ~model.noise.spherical
    [invK, UC] = pdinv(K+diag(1./model.B(:, i)));
    logDetTerm = logdet(K, UC);
  end
  L = L -.5*logDetTerm- .5*m(:, i)'*invK*m(:, i);
end
