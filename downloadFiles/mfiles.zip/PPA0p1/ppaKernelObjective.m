function f = ppaKernelObjective(params, model)

% PPAKERNELOBJECTIVE Likelihood approximation.
%
% f = ppaKernelObjective(params, model)

% Copyright (c) 2005 Nathaniel J. King and Neil D. Lawrence
% File version 1.1, Sun Mar  6 18:33:25 2005
% PPA toolbox version 0.1



model.kern = kernExpandParam(model.kern, params);
f = ppaKernelLogLikelihood(model);
f = f + kernPriorLogProb(model.kern);
f = -f;
