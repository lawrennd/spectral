function [X, Y, Z, varZ] = ppaMeshVals(model, limx, limy, number)

% PPAMESHVALS Give the output of the PPA for contour plot display.
%
% [X, Y, Z, varZ] = ppaMeshVals(model, limx, limy, number)

% Copyright (c) 2005 Nathaniel J. King and Neil D. Lawrence
% File version 1.1, Fri Mar  4 20:37:39 2005
% PPA toolbox version 0.1



x = linspace(limx(1), limx(2), number);
y = linspace(limy(1), limy(2), number);
[X, Y] = meshgrid(x, y);

[Z, varZ] = ppaPosteriorMeanVar(model, [X(:) Y(:)]);
Z = reshape(Z, size(X));
varZ = reshape(varZ, size(X));