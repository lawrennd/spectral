function options = ppaOptions;

% PPAOPTIONS Default options for the probabilistic point assimilation.
%
% options = ppaOptions;

% Copyright (c) 2005 Nathaniel J. King and Neil D. Lawrence
% File version 1.3, Fri Jun  3 20:47:53 2005
% PPA toolbox version 0.1



options.display = 0; % this is display for likelihood changes.
options.kernDisplay = 0; % this is display for kernel optimisation.
options.tol = 1e-5; % this gives the likelihood tolerance.
options.scalarB = 1;
options.maxOuterIter = 5000;
options.kernIters = 100;
options.varKern = 0; % this determines whether we use the variational kernel likelihood