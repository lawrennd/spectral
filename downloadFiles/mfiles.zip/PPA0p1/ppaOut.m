function y = ppaOut(model, x);

% PPAOUT Evaluate the output of an ppa model.
%
% y = ppaOut(model, x);

% Copyright (c) 2005 Nathaniel J. King and Neil D. Lawrence
% File version 1.2, Fri Jun  3 20:47:53 2005
% PPA toolbox version 0.1



[mu, varsigma] = ppaPosteriorMeanVar(model, x);
y = noiseOut(model.noise, mu, varsigma);
