function model = ppaUpdateB(model)

% PPAUPDATEB Update the individual values of B.
%
% model = ppaUpdateB(model)

% Copyright (c) 2005 Nathaniel J. King and Neil D. Lawrence
% File version 1.1, Sun Mar  6 12:41:46 2005
% PPA toolbox version 0.1



numData = size(model.y, 1);
for i=1:size(model.y, 2)
  model.B(:, i) = 1./(model.expectations.ff(:, i) ...
      -2.*model.expectations.fBar(:, i).*model.expectations.f(:, i) ...
      + diag(model.expectations.fBarfBar(:, :, i))); 
end