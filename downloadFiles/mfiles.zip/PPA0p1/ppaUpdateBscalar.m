function model = ppaUpdateBscalar(model)

% PPAUPDATEBSCALAR Update the values of B keeping each data dimension constant.
%
% model = ppaUpdateBscalar(model)

% Copyright (c) 2005 Nathaniel J. King and Neil D. Lawrence
% File version 1.2, Fri Jun  3 20:47:53 2005
% PPA toolbox version 0.1



numData = size(model.y, 1);
for i=1:size(model.y, 2)
  invAlpha = sum(model.expectations.ff(:, i)) ...
      -2.*model.expectations.fBar(:, i)'*model.expectations.f(:, i) ...
      + trace(model.expectations.fBarfBar(:, :, i)); 
  
  % Replacing B in the model with its update        
  model.B(:, i) = repmat(numData./invAlpha, numData, 1);
end