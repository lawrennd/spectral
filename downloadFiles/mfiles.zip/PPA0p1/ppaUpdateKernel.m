function model = ppaUpdateKernel(model, options)

% PPAUPDATEKERNEL Update the kernel parameters.
%
% model = ppaUpdateKernel(model, options)

% Copyright (c) 2005 Nathaniel J. King and Neil D. Lawrence
% File version 1.3, Fri Jun  3 20:47:53 2005
% PPA toolbox version 0.1



% Update the kernel parameters.
if ~options.varKern
 model=ppaOptimiseKernel(model, options.kernDisplay, options.kernIters);
 if options.display
     fprintf('Using non variational kernel update - ');
 end
else
 model=ppaVarLikeOptimiseKernel(model, options.kernDisplay, options.kernIters);
 if options.display
     fprintf('Using variational kernel update - ');
 end
end
model.kern.Kstore=kernCompute(model.kern, model.X);
model.kern.invKstore=pdinv(model.kern.Kstore);
