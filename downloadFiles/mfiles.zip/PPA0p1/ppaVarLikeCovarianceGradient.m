function g = ppaVarLikeCovarianceGradient(invK, m)

% PPAVARLIKECOVARIANCEGRADIENT The gradient of the variational likelihood approximation wrt the covariance.
%
% g = ppaVarLikeCovarianceGradient(invK, m)

% Copyright (c) 2005 Nathaniel J. King and Neil D. Lawrence
% File version 1.1, Fri Jun  3 19:55:01 2005
% PPA toolbox version 0.1



invKMInvK = invK*m*invK;

g = -invK + invKMInvK;
g= g*.5;
