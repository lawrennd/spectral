function g = ppaVarLikeKernelGradient(params, model)

% PPAVARLIKEKERNELGRADIENT Gradient of variational likelihood approximation wrt kernel parameters.
%
% g = ppaVarLikeKernelGradient(params, model)

% Copyright (c) 2005 Nathaniel J. King and Neil D. Lawrence
% File version 1.1, Fri Jun  3 19:55:01 2005
% PPA toolbox version 0.1




model.kern = kernExpandParam(model.kern, params);
g = ppaKernelLogLikeGrad(model);
g = g + kernPriorGradient(model.kern);
g = -g;
