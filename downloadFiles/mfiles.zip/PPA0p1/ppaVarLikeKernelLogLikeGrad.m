function g = ppaVarLikeKernelLogLikeGrad(model)

% PPVARLIKEAPPROXLOGLIKEKERNGRAD Gradient of the kernel variational likelihood wrt kernel parameters.
%
% g = ppaVarLikeKernelLogLikeGrad(model)

% Copyright (c) 2005 Nathaniel J. King and Neil D. Lawrence
% File version 1.1, Fri Jun  3 19:55:01 2005
% PPA toolbox version 0.1



x = model.X;
numData = size(x, 1);
m = model.expectations.fBarfBar;
K = kernCompute(model.kern, x);
g = zeros(1, model.kern.nParams);

if model.noise.spherical
  % there is only one value for all beta
  invK = pdinv(K);
end

for j = 1:size(m, 3)
  if ~model.noise.spherical
    invK = pdinv(K);
  end
  covGrad = feval([model.type 'CovarianceGradient'], invK, m(:,:, j));
  g = g + kernGradient(model.kern, x, covGrad);
end  
