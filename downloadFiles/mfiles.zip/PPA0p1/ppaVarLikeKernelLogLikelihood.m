function L = ppaVarLikeKernelLogLikelihood(model);

% PPAVARLIKEKERNELLOGLIKELIHOOD Return the approximate variational log-likelihood for the PPA.
%
% L = ppaVarLikeKernelLogLikelihood(model);

% Copyright (c) 2005 Nathaniel J. King and Neil D. Lawrence
% File version 1.1, Fri Jun  3 19:55:01 2005
% PPA toolbox version 0.1



x = model.X;
numData = size(x, 1);
m = model.expectations.fBarfBar;
K = kernCompute(model.kern, x);
L = 0;% should i have the two pi constant here -.5*numData*log(2*pi)

if model.noise.spherical
  % there is only one value for all beta
  [invK, UC] = pdinv(K);
  logDetTerm = logdet(K, UC);
end
  
for i = 1:size(m, 3)
  if ~model.noise.spherical
    [invK, UC] = pdinv(K);
    logDetTerm = logdet(K, UC);
  end
  L = L -.5*logDetTerm- .5*trace(m(:, :, i)*invK);
end