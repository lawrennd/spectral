function f = ppaVarLikeKernelObjective(params, model)

% PPAVARLIKEKERNELOBJECTIVE Variational Likelihood Kernel approximation.
%
% f = ppaVarLikeKernelObjective(params, model)

% Copyright (c) 2005 Nathaniel J. King and Neil D. Lawrence
% File version 1.1, Fri Jun  3 19:55:01 2005
% PPA toolbox version 0.1




model.kern = kernExpandParam(model.kern, params);
f = ppaVarLikeKernelLogLikelihood(model);
f = f + kernPriorLogProb(model.kern);
f = -f;