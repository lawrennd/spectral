function model = ppaVarLikeOptimiseKernel(model, display, iters);

% PPAOPTIMISEKERNEL Optimise the kernel parameters using the variational log-likelihood.
%
% model = ppaVarLikeOptimiseKernel(model, display, iters);

% Copyright (c) 2005 Nathaniel J. King and Neil D. Lawrence
% File version 1.1, Fri Jun  3 19:55:01 2005
% PPA toolbox version 0.1



if nargin < 3
  iters = 500;
  if nargin < 2
    display = 1;
  end
end
options = defaultOptions;
if display
  options(1) = 1;
end
options(14) = iters;

model = optimiseParams('kern', 'scg', 'ppaVarLikeKernelObjective', ...
                       'ppaVarLikeKernelGradient', options, model);