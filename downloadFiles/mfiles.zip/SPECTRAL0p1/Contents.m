% SPECTRAL toolbox
% Version 0.1		29-Apr-2005
% Copyright (c) 2005 Guido Sanguinetti and Jonathan Laidler
% 
% SPECTRALCLUSTER Clusters a dataset automatically determining the number of clusters.
% DEMOBASEBALL A demonstration of spectral clustering on the baseball image.
% DEMOCIRCLES A demonstration of spectral clustering on the three circles data set.
% DEMOEAR a demonstration of spectral clustering on the ear data set.
% DEMOSHAPES A demonstration of spectral clustering on the shapes data set (sigma=1).
% DEMOSHAPES2 A demonstration of spectral clustering on the shapes data set (sigma=2).
% DEMOSPECTROGRAM A demonstration of spectral clustering on acoustic data (sigma=3.5).
% DEMOSPECTROGRAM A demonstration of spectral clustering on acoustic data (sigma=2.5).
% DEMOSWIRLS A demonstration of spectral clustering on the swirls data set.
% MAHDIST2 Calculates Mahalanobis distance between two sets of points (based on Netlab dist2).
% MAHKMEANS Trains a k means cluster model, using Mahalanobis distance (based on Netlab k-means).
